//
//  ViewController.swift
//  Keychain
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // 1
    @IBOutlet weak var serviceNameTextField: UITextField!
    @IBOutlet weak var accountTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    // MARK: - Actions
    // 2
    @IBAction func savePasswordTapHandler(sender: UIButton) {
        guard let service = serviceNameTextField.text, let account = accountTextField.text, let password = passwordTextField.text,
            !service.isEmpty, !account.isEmpty, !password.isEmpty else {
                print("not all data entered")
                return
        }
        
        let result = savePassword(password: password, service: service, account: account)
        
        if result, let savedPassword = readPassword(service: service, account: account) {
            print("password:\(savedPassword) saved successfully with service name:\(service) and account:\(account)")
        } else {
            print("can't save password")
        }
    }
    // 3
    @IBAction func readPasswordTapHandler(sender: UIButton) {
        guard let service = serviceNameTextField.text, let account = accountTextField.text, !service.isEmpty, !account.isEmpty else {
                return
        }
        
        guard let password = readPassword(service: service, account: account) else {
            print("can't read password for service name:\(service) and account:\(account)")
            return
        }
        
        print("password:\(password) for service name:\(service) and account:\(account)")
    }
    // 4
    @IBAction func readAllPasswordsTapHandler(sender: UIButton) {
        guard let service = serviceNameTextField.text, !service.isEmpty else {
            print("no service name entered")
            return
        }
        
        let passwordItems = readAllItems(service: service)
        print("\(service): \(passwordItems ?? [:])")
    }
    // 5
    @IBAction func deletePasswordTapHandler(sender: UIButton) {
        guard let service = serviceNameTextField.text, let account = accountTextField.text, !service.isEmpty, !account.isEmpty else {
            return
        }
        
        let result = deletePassword(service: service, account: account)
        
        if result {
            print("password for service name:\(service) and account:\(account) successfully deleted")
        } else {
            print("can't delete password for service name:\(service) and account:\(account)")
        }
    }
    
    // MARK: - Private
    // 6
    private func keychainQuery(service: String, account: String? = nil) -> [String : AnyObject] {
        var query = [String : AnyObject]()
        query[kSecClass as String] = kSecClassGenericPassword
        query[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlocked
        query[kSecAttrService as String] = service as AnyObject
        
        if let account = account {
            query[kSecAttrAccount as String] = account as AnyObject
        }
        
        return query
    }
    // 7
    private func readPassword(service: String, account: String?) -> String? {
        var query = keychainQuery(service: service, account: account)
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        query[kSecReturnData as String] = kCFBooleanTrue
        query[kSecReturnAttributes as String] = kCFBooleanTrue
        
        var queryResult: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, UnsafeMutablePointer(&queryResult))
        
        if status != noErr {
            return nil
        }
        
        guard let item = queryResult as? [String : AnyObject],
            let passwordData = item[kSecValueData as String] as? Data,
            let password = String(data: passwordData, encoding: .utf8) else {
                return nil
        }
        return password
    }
    // 8
    private func readAllItems(service: String) -> [String : String]? {
        var query = keychainQuery(service: service)
        query[kSecMatchLimit as String] = kSecMatchLimitAll
        query[kSecReturnData as String] = kCFBooleanTrue
        query[kSecReturnAttributes as String] = kCFBooleanTrue
        
        var queryResult: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, UnsafeMutablePointer(&queryResult))
        
        if status != noErr {
            return nil
        }
        
        guard let items = queryResult as? [[String : AnyObject]] else {
            return nil
        }
        var passwordItems = [String : String]()
        
        for (index, item) in items.enumerated() {
            guard let passwordData = item[kSecValueData as String] as? Data,
                let password = String(data: passwordData, encoding: .utf8) else {
                    continue
            }
            
            if let account = item[kSecAttrAccount as String] as? String {
                passwordItems[account] = password
                continue
            }
            
            let account = "empty account \(index)"
            passwordItems[account] = password
        }
        return passwordItems
    }
    // 9
    private func savePassword(password: String, service: String, account: String?) -> Bool {
        let passwordData = password.data(using: .utf8)
        
        if readPassword(service: service, account: account) != nil {
            var attributesToUpdate = [String : AnyObject]()
            attributesToUpdate[kSecValueData as String] = passwordData as AnyObject
            
            let query = keychainQuery(service: service, account: account)
            let status = SecItemUpdate(query as CFDictionary, attributesToUpdate as CFDictionary)
            return status == noErr
        }
        
        var item = keychainQuery(service: service, account: account)
        item[kSecValueData as String] = passwordData as AnyObject
        let status = SecItemAdd(item as CFDictionary, nil)
        return status == noErr
    }
    // 10
    private func deletePassword(service: String, account: String?) -> Bool {
        let item = keychainQuery(service: service, account: account)
        let status = SecItemDelete(item as CFDictionary)
        return status == noErr
    }
    
}
