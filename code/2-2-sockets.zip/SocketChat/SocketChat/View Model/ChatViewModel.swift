//
//  ChatModel.swift
//  SocketChat
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation

enum NetworkConnectionType: String {
    case CFStream
    case streamTask
}

protocol ChatViewModelDelegate: class {
    func receivedMessage(message: ChatMessage, index: Int)
}

class ChatViewModel: NSObject {
    
    // MARK: Model Variables
    var connectionType: NetworkConnectionType
    var streamTask: URLSessionStreamTask?
    
    var inputStream: InputStream!
    var outputStream: OutputStream!
    
    var username = ""
    
    let maxReadLength = 4096
    
    weak var delegate: ChatViewModelDelegate?
    
    var messages: [ChatMessage] = {
        return [
            ChatMessage(username: "Yuri", message: nil, messageType: .user, userType: .me),
            ChatMessage(username: "Yuri", message: "Hello world", messageType: .message, userType: .me),
            ChatMessage(username: "Vasya", message: nil, messageType: .user, userType: .other),
            ChatMessage(username: "Vasya", message: "Hello Yuri", messageType: .message, userType: .other),
            ]
    }()
    
    // MARK: Model Initialization
    init(with type: NetworkConnectionType) {
        self.connectionType = type
        super.init()
    }

}

// MARK: General Chat Functions

extension ChatViewModel {
    
    func setupNetwork() {
        switch connectionType {
        case .CFStream:
            setupSocketsNetwork()
        case .streamTask:
            setupSessionNetwork()
        }
    }
    
    func joinChat() {
        let data = "user:\(username)".data(using: .ascii)!
        
        send(data: data)
    }
    
    func sendMessage(message: String) {
        let data = "msg:\(message)".data(using: .ascii)!
        
        send(data: data)
    }
    
    private func send(data: Data) {
        switch connectionType {
        case .CFStream:
            _ = data.withUnsafeBytes {
                outputStream.write($0, maxLength: data.count)
            }
        case .streamTask:
            streamTask?.write(data, timeout: 10.0) {
                error in
            }
        }
    }
    
    func stopChatSession() {
        switch connectionType {
        case .CFStream:
            inputStream.close()
            outputStream.close()
        case .streamTask:
            streamTask?.cancel()
        }
    }
    
}

// MARK: CFStream Connection

extension ChatViewModel {

    private func setupSocketsNetwork() {
        var readStream: Unmanaged<CFReadStream>?
        var writeStream: Unmanaged<CFWriteStream>?
        
        CFStreamCreatePairWithSocketToHost(kCFAllocatorDefault,
                                           "localhost" as CFString,
                                           80,
                                           &readStream,
                                           &writeStream)
        
        inputStream = readStream!.takeRetainedValue()
        outputStream = writeStream!.takeRetainedValue()
        
        inputStream.delegate = self
        
        inputStream.schedule(in: .current, forMode: .commonModes)
        outputStream.schedule(in: .current, forMode: .commonModes)
        
        inputStream.open()
        outputStream.open()
    }

}

// MARK: Input Stream Delegate

extension ChatViewModel: StreamDelegate {
    
    func stream(_ aStream: Stream, handle eventCode: Stream.Event) {
        switch eventCode {
        case Stream.Event.hasBytesAvailable:
            print("data available event")
            readAvailableBytes(stream: aStream as! InputStream)
        default:
            print("other event")
        }
    }
    
    private func readAvailableBytes(stream: InputStream) {
        let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: maxReadLength)
        while stream.hasBytesAvailable {
            let numberOfBytesRead = inputStream.read(buffer, maxLength: maxReadLength)
            
            if numberOfBytesRead < 0 {
                if stream.streamError != nil {
                    break
                }
            }
            
            if let message = message(with: buffer, length: numberOfBytesRead) {
                self.messages.append(message)
                self.delegate?.receivedMessage(message: message, index: self.messages.index(before: self.messages.endIndex))
            }
        }
    }
    
}

// MARK: Stream Task Connection

extension ChatViewModel {
    
    private func setupSessionNetwork() {
        let session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
        streamTask = session.streamTask(withHostName: "localhost", port: 80)
        streamTask?.resume()
        
        DispatchQueue.global().async {
            [weak self] in
            
            self?.readStreamTaskData()
        }
    }
    
    private func readStreamTaskData() {
        guard let streamTask = streamTask else {
            return
        }
        
        streamTask.readData(ofMinLength: 1, maxLength: maxReadLength, timeout: 0, completionHandler: {
            [weak self] (data: Data?, eof: Bool, error: Error?) in
            
            guard let `self` = self, eof == false else {
                return
            }

            if let data = data, let message = self.message(with: data) {
                DispatchQueue.main.async {
                    self.messages.append(message)
                    self.delegate?.receivedMessage(message: message, index: self.messages.index(before: self.messages.endIndex))
                }
            }
            
            self.readStreamTaskData()
        })
    }
    
}

// MARK: Parse Data

extension ChatViewModel {
    
    private func message(with buffer: UnsafeMutablePointer<UInt8>, length: Int) -> ChatMessage? {
        let data = Data(bytesNoCopy: buffer, count: length, deallocator: .free)
        
        return message(with: data)
    }
    
    private func message(with data: Data) -> ChatMessage? {
        guard let stringArray = String(data: data, encoding: .ascii)?.components(separatedBy: ":"),
            let username = stringArray.first,
            let message = stringArray.last else {
                return nil
        }
        
        return ChatMessage(username: username, message: message, messageType: username == message ? .user : .message, userType: username == self.username ? .me : .other)
    }
}

extension ChatViewModel: URLSessionDelegate {
    
}
