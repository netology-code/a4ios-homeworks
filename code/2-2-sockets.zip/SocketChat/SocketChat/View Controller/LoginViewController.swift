//
//  ViewController.swift
//  SocketChat
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var loginTextField: UITextField!
    
    @IBAction func loginButtonTapped(_ sender: UIButton) {
        guard let username = loginTextField.text, !username.isEmpty else {
            return
        }
        
        showChat(with: username)
    }
    
    func showChat(with username: String) {
        let chatVC = UIStoryboard(name: "Chat", bundle: nil).instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        chatVC.username = username
        
        self.navigationController?.show(chatVC, sender: self)
    }
    
}
