//
//  ChatViewController.swift
//  SocketChat
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ChatViewController: UIViewController {
    
    struct Cells {
        static let user = String(describing: UserTableViewCell.self)
        static let message = String(describing: MessageTableViewCell.self)
    }
    
    var chatViewModel: ChatViewModel
    var username = ""
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageTextField: UITextField!
    
    @IBAction func sendButtonTapped(_ sender: UIButton) {
        guard let message = messageTextField.text, !message.isEmpty else {
            return
        }
        
        messageTextField.text = nil
        chatViewModel.sendMessage(message: message)
    }
    
    // MARK: View Controller Init
    required init?(coder aDecoder: NSCoder) {
        self.chatViewModel = ChatViewModel(with: .CFStream)
//        self.chatViewModel = ChatViewModel(with: .streamTask)
        
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTableView()
        setupChat()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        chatViewModel.stopChatSession()
        
        super.viewWillDisappear(animated)
    }
    
    func setupTableView() {
        tableView.register(UINib(nibName: Cells.user, bundle: nil), forCellReuseIdentifier: Cells.user)
        tableView.register(UINib(nibName: Cells.message, bundle: nil), forCellReuseIdentifier: Cells.message)
        tableView.dataSource = self
    }
    
    // MARK: Chat Setup
    func setupChat() {
        chatViewModel.username = username
        chatViewModel.delegate = self
        chatViewModel.setupNetwork()
        chatViewModel.joinChat()
    }
    
}

// MARK: Message Receive Delegate
extension ChatViewController: ChatViewModelDelegate {
    
    func receivedMessage(message: ChatMessage, index: Int) {
        tableView.insertRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }
    
}

extension ChatViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return chatViewModel.messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch chatViewModel.messages[indexPath.row].messageType {
        case .user:
            let cell = tableView.dequeueReusableCell(withIdentifier: Cells.user, for: indexPath) as! UserTableViewCell
            cell.configure(username: chatViewModel.messages[indexPath.row].username)
            
            return cell
        case .message:
            let cell = tableView.dequeueReusableCell(withIdentifier: Cells.message, for: indexPath) as! MessageTableViewCell
            cell.configure(message: chatViewModel.messages[indexPath.row].message ?? "",
                           username: chatViewModel.messages[indexPath.row].username,
                           type: chatViewModel.messages[indexPath.row].userType)

            return cell
        }
    }
    
}
