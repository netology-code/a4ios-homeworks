//
//  UserTableViewCell.swift
//  SocketChat
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class UserTableViewCell: UITableViewCell {
    
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var bubbleView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        bubbleView.layer.cornerRadius = 8
    }
    
    func configure(username: String) {
        usernameLabel.text = username
    }
    
}
