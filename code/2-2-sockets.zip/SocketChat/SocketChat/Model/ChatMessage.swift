//
//  ChatMessage.swift
//  SocketChat
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation

enum MessageType: String {
    case message
    case user
}

enum UserType: String {
    case me
    case other
}

struct ChatMessage {
    var username: String
    var message: String?
    var messageType: MessageType
    var userType: UserType
}
