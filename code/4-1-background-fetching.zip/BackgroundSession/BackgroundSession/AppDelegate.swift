//
//  AppDelegate.swift
//  BackgroundSession
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

typealias BackgroundCompletion = () -> Void

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var backgroundCompletionHandler: BackgroundCompletion?
    var window: UIWindow?
    // 10
    func application(_ application: UIApplication, handleEventsForBackgroundURLSession identifier: String, completionHandler: @escaping () -> Void) {
        // 11
        backgroundCompletionHandler = completionHandler
        print("handle Events For Background URL Session with identifier: \(identifier)")
    }
}
