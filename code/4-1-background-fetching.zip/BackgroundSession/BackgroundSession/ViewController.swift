//
//  ViewController.swift
//  BackgroundSession
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    private let downloadURL = "https://www.iso.org/files/live/sites/isoorg/files/archive/pdf/en/annual_report_2009.pdf"
    private var backgroundSession: URLSession?
    
    // MARK: - Init
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        // 5
        let backgroundConfiguration = URLSessionConfiguration.backgroundConfiguration()
        backgroundSession = URLSession(configuration: backgroundConfiguration, delegate: self, delegateQueue: nil)
    }
    
    // MARK: - Actions
    
    @IBAction func downloadButtonTapHandler(sender: UIButton) {
        // 6
        guard let url = URL(string: downloadURL), let backgroundTask = backgroundSession?.downloadTask(with: url) else {
            print("can't create background Task")
            return
        }
        // 7
        backgroundTask.earliestBeginDate = Date().addingTimeInterval(5)
        // 8
        backgroundTask.countOfBytesClientExpectsToSend = 512
        // 9
        backgroundTask.countOfBytesClientExpectsToReceive = 11 * 1024 * 1024 // 11MB
        backgroundTask.resume()
    }
}

extension ViewController: URLSessionDownloadDelegate {
    // 12
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        print("did Finish Downloading To: \(location)")
        // 13
        guard let httpResponse = downloadTask.response as? HTTPURLResponse,
            (200...299).contains(httpResponse.statusCode) else {
                print ("server error")
                return
        }
        // 14
        do {
            let documentsURL = try FileManager.default.url(for: .documentDirectory,
                                                           in: .userDomainMask,
                                                           appropriateFor: nil,
                                                           create: false)
            let destinationURL = documentsURL.appendingPathComponent(location.lastPathComponent)
            try FileManager.default.moveItem(at: location, to: destinationURL)
            print("file moved to url: \(destinationURL)")
        } catch {
            print("error: \(error)")
        }
    }
    // 15
    func urlSessionDidFinishEvents(forBackgroundURLSession session: URLSession) {
        DispatchQueue.main.async {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate, let completionHandler = appDelegate.backgroundCompletionHandler else {
                return
            }
            appDelegate.backgroundCompletionHandler = nil
            completionHandler()
            print("url Session Did Finish Events")
        }
    }
    // 16
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error {
            print("did Complete With Error: \(error)")
        }
    }
}

extension URLSessionConfiguration {
    // 1
    class func backgroundConfiguration() -> URLSessionConfiguration {
        // 2
        let bg = URLSessionConfiguration.background(withIdentifier: "com.e-legion.background.session")
        // 3
        bg.sessionSendsLaunchEvents = true
        // 4
        bg.isDiscretionary = true
        return bg
    }
}
