//
//  ViewController.swift
//  SenderDL
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // MARK: - Actions
    // 1
    @IBAction func openMap(sender: UIButton) {
        openURLScheme(urlScheme: "http://maps.apple.com/?ll=50.894967,4.341626")
    }
    // 2
    @IBAction func openSMS(sender: UIButton) {
        openURLScheme(urlScheme: "sms:")
    }
    // 3
    @IBAction func openCustomURLScheme(sender: UIButton) {
        openURLScheme(urlScheme: "receiverdl://e-legion.com?text=The text from SenderDL app")
    }
    
    // MARK: - Private
    // 4
    private func openURLScheme(urlScheme: String) {
        // 5
        guard let text = urlScheme.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
            let url = URL(string: text) else {
            print("wrong urlScheme:\(urlScheme)")
            return
        }
        // 6
        if UIApplication.shared.canOpenURL(url) {
            // 7
            UIApplication.shared.open(url, options: [:]) { (success) in
                if success {
                    print("url \(url) opened successfully")
                }
            }
        } else {
            let alert = UIAlertController(title: "Unable to open link", message: nil, preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: {_ in
                self.dismiss(animated: true, completion: nil)
            })
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
        }
    }
}
