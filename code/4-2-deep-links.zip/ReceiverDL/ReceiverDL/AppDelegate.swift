//
//  AppDelegate.swift
//  ReceiverDL
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    // 1
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        // 2
        guard let urlComponents = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
            return false
        }
        // 3
        if urlComponents.scheme != "receiverdl" {
            return false
        }
        // 4
        if let host = urlComponents.host, host != "e-legion.com" {
            return false
        }
        // 5
        guard let firstQueryItemValue = urlComponents.queryItems?.first?.value else {
            return false
        }
        // 6
        guard let appDelegate = app.delegate as? AppDelegate,
            let rootViewController = appDelegate.window?.rootViewController as? ViewController else {
            return false
        }
        // 7
        rootViewController.textLabel.text = firstQueryItemValue
        return true
    }
}
