//: Playground - noun: a place where people can play

import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

// 1
struct CityWeather {
    private(set) var name: String
    private(set) var temperature: Double
    private(set) var humidity: Int
    private(set) var pressure: Double
    private(set) var weather: Weather
    
    struct Weather {
        enum Main: String {
            case Rain, Sun, Snow, Mist, Fog, Haze
        }
        private(set) var main: String
        private(set) var description: String
        
        //3
        init? (json: [Dictionary<String, Any>]) {
            
            guard let weatherType = json[0]["main"] as? String,
                let description = json[0]["description"] as? String else {
                    return nil
            }
            
            guard let main = Main(rawValue: weatherType) else {
                return nil
            }
            
            self.main = main.rawValue
            self.description = description
        }
    }
    
    //2
    init? (json: [String: Any] ) {
        guard let name = json["name"] as? String,
            let mainDict = json["main"] as? Dictionary<String, Any>,
            let temp = mainDict["temp"] as? Double,
            let pressure = mainDict["pressure"] as? Double,
            let humidity = mainDict["humidity"] as? Int,
            let weather = json["weather"] as? [Dictionary<String, Any>] else {
                return nil
        }
        self.name = name
        self.temperature = temp
        self.humidity = humidity
        self.pressure = pressure
        self.weather = Weather(json: weather)!
    }
    
}

enum BackendError: Error {
    case urlError(reason: String)
    case objectSerialization(reason: String)
}

//5
enum Result<T> {
    case success(T)
    case fail(Error)
}

// 4
func getWeatherForCity(cityName:String, completionHandler: @escaping (Result<CityWeather>) ->Void) {
    let londonURL = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=\(cityName)&appid=0077569810bfa11c5782f0d4aba6883e")!
    let session = URLSession.shared
    let task = session.dataTask(with: londonURL, completionHandler: {
        data, responce, error in
        
        guard error == nil else {
            completionHandler(.fail(error!))
            return
        }
        
        guard let responceData = data else {
            let error = BackendError.objectSerialization(reason: "No data in responce")
            completionHandler(.fail(error)!)
            return
        }
        
        do {
            if let json = try JSONSerialization.jsonObject(with: responceData, options: []) as? [String: Any],
                let city = CityWeather(json: json) {
                completionHandler(.success(city))
            } else {
                let error = BackendError.objectSerialization(reason: "Can't create object from JSON")
                completionHandler(.fail(error)!)
            }
        } catch {
            completionHandler(.fail(error)!)
            return
        }
    })
    task.resume()
}


//6
getWeatherForCity(cityName: "London") {
    result in
    
    switch result {
        
    case .success(let weather):
        print(weather)
    case .fail(let error):
        print(error)
    }
    
}


//7
func stringToJson() {
    let dict = ["location": "garden"]
    if let json = try? JSONSerialization.data(withJSONObject: dict, options: []) {
        if let content = String(data: json, encoding: String.Encoding.utf8) {
            print(content)
        }
    }
}

//stringToJson()
