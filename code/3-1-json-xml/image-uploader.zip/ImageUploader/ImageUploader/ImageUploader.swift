//
//  ImageUploader.swift
//  ImageUploader
//

import UIKit

class ImageUploader: NSObject {
    
    // MARK: Network
    
    weak var delegate: ImageUploaderDelegate?
    
    private let clientID = "c1508b1335ec0fe"
    
    // MARK: Boundary String
    
    private let boundaryString = "Boundary-\(UUID().uuidString)"
    
    public func upload(image: UIImage) {
        
        // MARK: Upload Image
        
        guard let url = URL(string: "https://api.imgur.com/3/image") else {
            return
        }
        
        let parameters = [
            "album"         : nil,
            "type"          : "base64",
            "name"          : nil,
            "title"         : nil,
            "description"   : nil,
            ]
        
        guard let request = try? createRequest(url: url, image: image, parameters: parameters) else {
            return
        }
        
        let task = defaultSession().dataTask(with: request)
        task.resume()
    }
    
    private func defaultSession() -> URLSession {
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
        
        return session
    }
    
    // MARK: Request
    
    private func createRequest(url: URL, image: UIImage, parameters: [String: String?]) throws -> URLRequest {
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Client-ID \(clientID)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundaryString)", forHTTPHeaderField: "Content-Type")
        
        let parameters = parameters.filter{ $0.value != nil }.mapValues{ $0! }
        
        request.httpBody = createBody(with: parameters, image: image, boundary: boundaryString)
        
        return request
    }
    
    private func createBody(with parameters: [String: String], image: UIImage, boundary: String) -> Data? {
        // MARK: Request Body
        
        guard let imageData = UIImagePNGRepresentation(image)?.base64EncodedData(),
            let base64ImageString = String(data: imageData, encoding: .utf8) else {
                return nil
        }
        
        var body = Data()
        
        for (key, value) in parameters {
            body.append(string: "--\(boundary)\r\n")
            body.append(string: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
            body.append(string: "\(value)\r\n")
        }
        
        body.append(string: "--\(boundary)\r\n")
        body.append(string: "Content-Disposition: form-data; name=\"image\"\r\n\r\n")
        body.append(string: base64ImageString)
        body.append(string: "\r\n")
        body.append(string: "--\(boundary)--\r\n")
        
        return body
    }
    
}

extension Data {
    
    // MARK: Data extension for String
    
    mutating func append(string: String) {
        guard let data = string.data(using: String.Encoding.utf8, allowLossyConversion: true) else {
            return
        }
        append(data)
    }
    
}

extension ImageUploader: URLSessionDataDelegate {
    
    // MARK: URL Session Delegate
    
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let response = response as? HTTPURLResponse, let delegate = delegate else {
            return
        }
        
        delegate.statusCodeUpdated(response.statusCode)
    }
    
}

protocol ImageUploaderDelegate: class {
    
    func statusCodeUpdated(_ code: Int)
    
}
