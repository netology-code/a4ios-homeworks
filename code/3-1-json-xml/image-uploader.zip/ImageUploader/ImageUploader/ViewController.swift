//
//  ViewController.swift
//  ImageUploader
//

import UIKit

class ViewController: UIViewController {
    
    // MARK: Interface
    
    var imagePickerController = UIImagePickerController()
    var imageUploader = ImageUploader()
    
    @IBOutlet weak var statusCodeLabel: UILabel!
    @IBOutlet weak var selectedImageView: UIImageView!
    
    @IBAction func selectImagePressed(_ sender: UIButton) {
        self.present(imagePickerController, animated: true, completion: nil)
    }

    @IBAction func uploadImagePressed(_ sender: UIButton) {
        guard let image = selectedImageView.image else {
            return
        }
        imageUploader.upload(image: image)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        
        imageUploader.delegate = self
    }
    
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    // MARK: UIImagePickerController Delegate
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            return
        }
        
        selectedImageView.image = image
        
        defer {
            imagePickerController.dismiss(animated: true, completion: nil)
        }
    }
    
}

extension ViewController: ImageUploaderDelegate {
    
    // MARK: ImageUplodaer Delegate
    
    func statusCodeUpdated(_ code: Int) {
        DispatchQueue.main.async {
            [weak self] in
            
            self?.statusCodeLabel.text = "Status code: \(code)"
        }
    }

}
