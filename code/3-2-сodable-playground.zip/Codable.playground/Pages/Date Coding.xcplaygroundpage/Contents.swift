import Foundation
// 3
extension DateFormatter {
    static let MMMdyyyy: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, yyyy"
        formatter.timeZone = TimeZone(identifier: "GMT")
        return formatter
    }()
}
// 1
let json = """
{
 "name" : "John Smith",
 "age" : 30,
 "birthDate" : "Aug 18, 1987"
}
""".data(using: .utf8)!
// 2
struct Person: Codable {
    var name: String
    var age: Int
    var birthDate: Date
}

let decoder = JSONDecoder()
let dateFormatter = DateFormatter.MMMdyyyy
// 4
decoder.dateDecodingStrategy = .formatted(dateFormatter)

if let person = try? decoder.decode(Person.self, from: json) {
    print(person)
} else {
    print("decoding failed")
}
// 5
let person = Person(name: "John Smith", age: 30, birthDate: dateFormatter.date(from: "Aug 18, 1987")!)
let encoder = JSONEncoder()
// 6
encoder.dateEncodingStrategy = .iso8601
let data = try? encoder.encode(person)

if let data = data, let string = String(data: data, encoding: .utf8) {
    print(string)
}
