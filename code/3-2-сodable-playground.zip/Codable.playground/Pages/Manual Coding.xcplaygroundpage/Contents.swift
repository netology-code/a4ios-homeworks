import Foundation
// 1
let jsonArray = """
[
 {
  "person_name" : "John Smith",
  "person_age" : 30,
  "phone" : "12345",
  "email" : "john_smith@gmail.com"
 },
 {
  "person_name" : "Bob Jones",
  "person_age" : 25,
  "phone" : "54321",
  "email" : "bob_jones@gmail.com"
 }
]
""".data(using: .utf8)!
// 2
struct Person {
    var name: String
    var age: Int
    var contacts: Contacts
    var country: String = "England"
    // 4
    private enum CodingKeys: String, CodingKey {
        case name = "person_name"
        case age = "person_age"
        case phone
        case email
    }
}
// 3
struct Contacts: Codable {
    var phone: String
    var email: String
}
// 5
extension Person: Decodable {
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decode(String.self, forKey: .name)
        age = try values.decode(Int.self, forKey: .age)
        let phone = try values.decode(String.self, forKey: .phone)
        let email = try values.decode(String.self, forKey: .email)
        contacts = Contacts(phone: phone, email: email)
        country = "England"
    }
}
// 6
extension Person: Encodable {
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(name, forKey: .name)
        try container.encode(age, forKey: .age)
        try container.encode(contacts.phone, forKey: .phone)
        try container.encode(contacts.email, forKey: .email)
    }
}

let decoder = JSONDecoder()
if let people = try? decoder.decode([Person].self, from: jsonArray) {
    people.forEach {
        print("name: \($0.name), age \($0.age), phone: \($0.contacts.phone), email: \($0.contacts.email), country: \($0.country)")
    }
}

let bob = Person(name: "Bob Jones", age: 25, contacts: Contacts(phone: "12345", email: "bob_jones@gmail.com"), country: "England")
let john = Person(name: "John Smith", age: 30, contacts: Contacts(phone: "54321", email: "john_smith@gmail.com"), country: "England")
let array = [bob, john]
let encoder = JSONEncoder()
let data = try? encoder.encode(array)

if let data = data, let string = String(data: data, encoding: .utf8) {
    print(string)
}
