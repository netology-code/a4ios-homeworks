import Foundation
// 1
let json = """
{
"name" : "John Smith",
"age" : 30
}
"""

// 2
struct Person: Codable {
    var name: String
    var age: Int
}
// 3
let jsonData = json.data(using: .utf8)!
let decoder = JSONDecoder()
// 4
if let person = try? decoder.decode(Person.self, from: jsonData) {
    print(person)
}
// 5
let anotherPerson = Person(name: "Bob Jones", age: 25)
// 6
let encoder = JSONEncoder()
// 7
let data = try? encoder.encode(anotherPerson)
// 8
if let data = data, let string = String(data: data, encoding: .utf8) {
    print(string)
}





