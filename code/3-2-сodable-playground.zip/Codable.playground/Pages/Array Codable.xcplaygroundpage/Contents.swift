import Foundation
// 1
var jsonArray = """
[
 {
  "name" : "John Smith",
  "age" : 30
 },
 {
  "name" : "Bob Jones",
  "age" : 25
 }
]
""".data(using: .utf8)!
// 2
struct Person: Codable {
    var name: String
    var age: Int
}
// 3
let decoder = JSONDecoder()
if let people = try? decoder.decode([Person].self, from: jsonArray) {
    people.forEach {
        print("name: \($0.name), age \($0.age)")
    }
}
// 4
let bob = Person(name: "Bob Jones", age: 25)
let john = Person(name: "John Smith", age: 30)
let array = [bob, john]
let encoder = JSONEncoder()
let data = try? encoder.encode(array)

if let data = data, let string = String(data: data, encoding: .utf8) {
    print(string)
}
