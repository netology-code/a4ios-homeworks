import Foundation
// 1
let jsonArray = """
[
 {
  "person_name" : "John Smith",
  "person_age" : 30,
  "contacts" : {
      "phone" : "12345",
      "email" : "john_smith@gmail.com"
   }
 },
 {
  "person_name" : "Bob Jones",
  "person_age" : 25,
  "contacts" : {
      "phone" : "54321",
      "email" : "bob_jones@gmail.com"
   }
 }
]
""".data(using: .utf8)!
// 2
struct Person: Codable {
    var name: String
    var age: Int
    var contacts: Contacts
    var country: String = "England"
    // 4
    private enum CodingKeys: String, CodingKey {
        case name = "person_name"
        case age = "person_age"
        case contacts
    }
}
// 3
struct Contacts: Codable {
    var phone: String
    var email: String
}

let decoder = JSONDecoder()
if let people = try? decoder.decode([Person].self, from: jsonArray) {
    people.forEach {
        print("name: \($0.name), age \($0.age), phone: \($0.contacts.phone), email: \($0.contacts.email), country: \($0.country)")
    }
}

let bob = Person(name: "Bob Jones", age: 25, contacts: Contacts(phone: "12345", email: "bob_jones@gmail.com"), country: "England")
let john = Person(name: "John Smith", age: 30, contacts: Contacts(phone: "54321", email: "john_smith@gmail.com"), country: "England")
let array = [bob, john]
let encoder = JSONEncoder()
let data = try? encoder.encode(array)

if let data = data, let string = String(data: data, encoding: .utf8) {
    print(string)
}
