import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

/**
 Если у вас нет учётки на гитхабе, необходимо предварительно создать её.
 Перед запуском кода необходимо создать токен в своём личном профиле в гитхабе и добавить его в переменную token.
 
 Инструкция по добавлению токена:
 
 1. Правый верхний угол -> Нажимаем на иконку с изображением вашего профайла -> Settings -> слева внизу нажимаем на Developer settings
 2. Выбираем Personal access tokens -> кнопка Generate new token
 3. Заполняем поле Token description (например, Playground token)
 4. Скроллим вниз и находим элемент user, ставим галочки напротив read:user и user:email
 5. Внизу есть кнопка Generate token, нажимаем на неё.
 6. Копируем полученный токен и добавляем его в переменную token
 */

class SessionDelegateExample: NSObject {
    // 1
    let token = ""
    let scheme = "https"
    let host = "api.github.com"
    let hostPath = "https://api.github.com"
    let emailPath = "/user/emails"
    let auth = "Authorization"
    let defaultHeaders = [
        "Content-Type" : "application/json",
        "Accept" : "application/vnd.github.v3+json"
    ]
    // 2
    lazy var defaultSession: URLSession = {
        // 3
        let configuration = URLSessionConfiguration.default
        // 4
        configuration.timeoutIntervalForRequest = 30
        // 5
        configuration.allowsCellularAccess = false
        // 6
        let queue = OperationQueue()
        queue.maxConcurrentOperationCount = 1
        // 7
        let session = URLSession(configuration: configuration, delegate: self, delegateQueue: queue)
        return session
    }()
    // 8
    func listOfRepositoriesRequest(userName: String) -> URLRequest? {
        guard let baseURL = URL(string: hostPath) else {
            return nil
        }
        
        let url = baseURL.appendingPathComponent("/users/\(userName)/repos")
        var request = URLRequest(url: url)
        request.allHTTPHeaderFields = defaultHeaders
        return request
    }
    // 9
    func addEmailAddressRequest() -> URLRequest? {
        var urlComponents = URLComponents()
        urlComponents.scheme = scheme
        urlComponents.host = host
        urlComponents.path = emailPath
        
        guard let url = urlComponents.url else {
            return nil
        }
        var request = URLRequest(url: url)
        
        var headers = defaultHeaders
        headers[auth] = "Bearer " + token
        
        let emailArray = "[\"test@github.com\", \"support@github.com\"]"
        let data = emailArray.data(using: .utf8)
        
        request.httpMethod = "POST"
        request.httpBody = data
        request.allHTTPHeaderFields = headers
        return request
    }
    // 10
    func performListOfRepositoriesRequest(userName: String) {
        guard let urlRequest = listOfRepositoriesRequest(userName: userName) else {
            print("url request error")
            return
        }
        
        let dataTask = defaultSession.dataTask(with: urlRequest)
        dataTask.resume()
    }
    // 11
    func performAddEmailAddressRequest() {
        guard let urlRequest = addEmailAddressRequest() else {
            print("url request error")
            return
        }
        
        let dataTask = defaultSession.dataTask(with: urlRequest)
        dataTask.resume()
    }
    
}
// 12
extension SessionDelegateExample: URLSessionDataDelegate {
    // 13
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard let text = String(data: data, encoding: .utf8) else {
            print("data encoding error")
            return
        }
        print("didReceive data: \(text)")
    }
    // 14
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error {
            print("didCompleteWithError:\(error.localizedDescription)")
        }
    }
    // 15
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Swift.Void) {
        if let httpResponse = response as? HTTPURLResponse {
            if httpResponse.statusCode == 401 {
                print("http response error: status code \(httpResponse.statusCode), description: Unauthorized")
                // 16
                completionHandler(URLSession.ResponseDisposition.cancel)
            } else {
                print("http status code: \(httpResponse.statusCode)")
                // 17
                completionHandler(URLSession.ResponseDisposition.allow)
            }
        }
    }

}
// 18
//let sessionDelegate = SessionDelegateExample()
// 19
//sessionDelegate.performListOfRepositoriesRequest(userName: "exyte")
// 20
//sessionDelegate.performAddEmailAddressRequest()
