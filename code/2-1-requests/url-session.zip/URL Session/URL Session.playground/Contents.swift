import Foundation
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

/**
 Если у вас нет учётки на гитхабе, необходимо предварительно создать её.
 Перед запуском кода необходимо создать токен в своём личном профиле в гитхабе и добавить его в переменную token.
 
 Инструкция по добавлению токена:
 
 1. Правый верхний угол -> Нажимаем на иконку с изображением вашего профайла -> Settings -> слева внизу нажимаем на Developer settings
 2. Выбираем Personal access tokens -> кнопка Generate new token
 3. Заполняем поле Token description (например, Playground token)
 4. Скроллим вниз и находим элемент user, ставим галочки напротив read:user и user:email
 5. Внизу есть кнопка Generate token, нажимаем на неё.
 6. Копируем полученный токен и добавляем его в переменную token
 */

let token = ""
let scheme = "https"
let host = "api.github.com"
let auth = "Authorization"

let hostPath = "https://api.github.com"
let repoPath = "/repositories"
let emailPath = "/user/emails"
let searchRepoPath = "/search/repositories"

let defaultHeaders = [
    "Content-Type" : "application/json",
    "Accept" : "application/vnd.github.v3+json"
]
// 1
func listOfPublicRepositoriesRequest() -> URLRequest? {
    // 2
    guard let baseURL = URL(string: hostPath) else {
        return nil
    }
    // 3
    let url = baseURL.appendingPathComponent(repoPath)
    // 4
    var request = URLRequest(url: url)
    // 5
    request.allHTTPHeaderFields = defaultHeaders
    return request
}
// 6
func listOfRepositoriesRequest(userName: String) -> URLRequest? {
    guard let baseURL = URL(string: hostPath) else {
        return nil
    }
    // 7
    let url = baseURL.appendingPathComponent("/users/\(userName)/repos")
    var request = URLRequest(url: url)
    request.allHTTPHeaderFields = defaultHeaders
    return request
}
// 8
func searchRepositoriesRequest() -> URLRequest? {
    // 9
    var urlComponents = URLComponents()
    // 10
    urlComponents.scheme = scheme
    // 11
    urlComponents.host = host
    // 12
    urlComponents.path = searchRepoPath
    // 13
    urlComponents.queryItems = [
        URLQueryItem(name: "q", value: "tetris+language:swift+stars:>3"),
        URLQueryItem(name: "sort", value: "stars"),
        URLQueryItem(name: "order", value: "desc")
    ]
    // 14
    guard let url = urlComponents.url else {
        return nil
    }
    print("search request url:\(url)")
    var request = URLRequest(url: url)
    request.allHTTPHeaderFields = defaultHeaders
    return request
}
// 15
func addEmailAddressRequest() -> URLRequest? {
    var urlComponents = URLComponents()
    urlComponents.scheme = scheme
    urlComponents.host = host
    urlComponents.path = emailPath
    
    guard let url = urlComponents.url else {
        return nil
    }
    var request = URLRequest(url: url)
    
    var headers = defaultHeaders
    // 16
    headers[auth] = "Bearer " + token
    // 17
    let emailArray = "[\"test@github.com\", \"support@github.com\"]"
    // 18
    let jsonData = emailArray.data(using: .utf8)
    // 19
    request.httpMethod = "POST"
    // 20
    request.httpBody = jsonData
    // 21
    request.allHTTPHeaderFields = headers
    return request
}

// 22
let sharedSession = URLSession.shared
// 23
func performListOfRepositoriesRequest() {
    // 24
    guard let urlRequest = listOfPublicRepositoriesRequest() else {
        print("url request error")
        return
    }
    //25
    let dataTask = sharedSession.dataTask(with: urlRequest) { (data, response, error) in
        // 26
        if let error = error {
            print(error.localizedDescription)
            return
        }
        // 27
        if let httpResponse = response as? HTTPURLResponse {
            print("http status code: \(httpResponse.statusCode)")
        }
        // 28
        guard let data = data else {
            print("no data received")
            return
        }
        // 29
        guard let text = String(data: data, encoding: .utf8) else {
            print("data encoding failed")
            return
        }
        // 30
        print("received data: \(text)")
    }
    dataTask.resume()
}
// 31
func performListOfRepositoriesRequest(userName: String) {
    guard let urlRequest = listOfRepositoriesRequest(userName: userName) else {
        print("url request error")
        return
    }
    
    let dataTask = sharedSession.dataTask(with: urlRequest) { (data, response, error) in
        if let error = error {
            print(error.localizedDescription)
            return
        }
        
        if let httpResponse = response as? HTTPURLResponse {
            print("http status code: \(httpResponse.statusCode)")
        }
        
        guard let data = data else {
            print("no data received")
            return
        }
        
        guard let text = String(data: data, encoding: .utf8) else {
            print("data encoding failed")
            return
        }
        print("received data: \(text)")
    }
    dataTask.resume()
}
// 32
func performSearchRepoRequest() {
    guard let urlRequest = searchRepositoriesRequest() else {
        print("url request error")
        return
    }
    
    let dataTask = sharedSession.dataTask(with: urlRequest) { (data, response, error) in
        if let error = error {
            print(error.localizedDescription)
            return
        }
        
        if let httpResponse = response as? HTTPURLResponse {
            print("http status code: \(httpResponse.statusCode)")
        }
        
        guard let data = data else {
            print("no data received")
            return
        }
        
        guard let text = String(data: data, encoding: .utf8) else {
            print("data encoding failed")
            return
        }
        print("received data: \(text)")
    }
    dataTask.resume()
}
// 33
func performAddEmailAddressRequest() {
    guard let urlRequest = addEmailAddressRequest() else {
        print("url request error")
        return
    }
    let dataTask = sharedSession.dataTask(with: urlRequest) { (data, response, error) in
        if let error = error {
            print(error.localizedDescription)
            return
        }
        // 34
        if let httpResponse = response as? HTTPURLResponse {
            if httpResponse.statusCode == 401 {
                print("http response error: status code \(httpResponse.statusCode), description: Unauthorized")
                return
            }
            print("http status code: \(httpResponse.statusCode)")
        }
        
        guard let data = data else {
            print("no data received")
            return
        }
        
        guard let text = String(data: data, encoding: .utf8) else {
            print("data encoding failed")
            return
        }
        print("received data: \(text)")
    }
    dataTask.resume()
}

// 35
//performListOfRepositoriesRequest()
// 36
//performListOfRepositoriesRequest(userName: "exyte")
// 37
//performSearchRepoRequest()
// 38
//performAddEmailAddressRequest()
